from copy import deepcopy

import numpy as np


from bayesmark.abstract_optimizer import AbstractOptimizer
from bayesmark.experiment import experiment_main
from bayesmark.space import JointSpace



class CrossEnthropy(AbstractOptimizer):
    primary_import = None


    class Variable: 
        def __init__(self,type_v,max_v=0,min_v=0,categorical_values=[]):
            self.type = type_v
            self.max_v = max_v
            self.min_v = min_v
            self.categories = list(categorical_values)
            
        def parse_inside(self,value): # takes element value / convert to Normal law
            if self.type=="cat":
                ls = [0.0]*len(self.categories)
                in_v = self.categories.index(value)
                ls[in_v] = 1.0
                return ls
            elif self.type=="bool":
                if value:
                    return [1.0]
                else:
                    return [0.0]
            else:
                return [value]
        
        def parse_outside(self,values_list): # takes normal vals -> must return values
            if self.type=="cat":
                return self.categories[np.argmax(values_list)]
            elif self.type=="bool":
                return values_list[0]>0.0
            elif self.type=="int":
                val = int(values_list[0]+0.5)
                if(val>self.max_v):
                    return self.max_v
                elif val<self.min_v:
                    return self.min_v
                else:
                    return val
            else:
                val = values_list[0]
                if(val>self.max_v):
                    return self.max_v
                elif val<self.min_v:
                    return self.min_v
                else:
                    return val
        
        def get_required_chunck_length(self):
            if self.type=="cat":
                return len(self.categories)
            else:
                return 1
            
        def get_initial_mean(self):
            if self.type == "cat":
                return [0.0]*len(self.categories)
            elif self.type == "bool":
                return [0.0]
            elif self.type == "int":
                return [(self.min_v+self.max_v)/2]
            elif self.type == "real":
                return [(self.min_v+self.max_v)/2]
            
        def get_initial_variances_diag(self):
            if self.type == "cat":
                return [1.0]*len(self.categories)
            elif self.type == "bool":
                return [1.0]
            elif self.type == "int":
                return [((-self.min_v+self.max_v)/6)**2]
            elif self.type == "real":
                return [((-self.min_v+self.max_v)/6)**2]
        
    class Parser:
        def __init__(self,api_config):
            self.keys = []
            self.interpretors = []
            #type_v is one of 'real', 'int', 'cat', 'bool'
            for variables in api_config.keys():
                self.keys.append(variables)
            
            for param_name in self.keys:
                param_config = api_config[param_name]

                param_type = param_config["type"]
                param_space = param_config.get("space", None)
                param_range = param_config.get("range", None)
                param_values = param_config.get("values", None)

                if param_type == "cat":
                    self.interpretors.append(Variable(param_type,categorical_values=param_values))
                    
                elif param_type == "bool":
                    self.interpretors.append(Variable(param_type))

                elif param_type == "int":
                    self.interpretors.append(Variable(param_type,max_v=param_range[1],min_v=param_range[0]))
                    
                elif param_type == "real":
                    self.interpretors.append(Variable(param_type,max_v=param_range[1],min_v=param_range[0]))
    
            
        def initial_mean_and_variance(self):
            means = []
            for inter in self.interpretors:
                means = means+inter.get_initial_mean()
            
            size = len(means)
            var = []
            for i in range(0,size):
                var.append([0.0]*size)
                
            index = 0
            for inter in self.interpretors:
                for j in inter.get_initial_variances_diag():
                    var[index][index] = j
                    index+=1
            return (means,var)
        
        def convert_for_outside(self,inside_val:np.array): # our regular data as described / inside_val is adequate np.array
            ls = list(inside_val)
            out = {}
            index = 0
            for i in range(0,len(self.keys)):
                name = self.keys[i]
                var = self.interpretors[i]
                out[name] = var.parse_outside(ls[index:index+var.get_required_chunck_length()])
                index += var.get_required_chunck_length()
            # return a dict 
            return out
        
        def convert_for_inside(self,outside_val:dict)->np.array: # one hot and normal laws
            index = 0
            ls = []
            for key in self.keys:
                variable = self.interpretors[index]
                ls = ls + variable.parse_inside(outside_val[key])
                index+=1
            return np.array(ls)
            
    
    def __init__(self, api_config, **kwargs):
        """Build wrapper class to use an optimizer in benchmark.

        Parameters
        ----------
        api_config : dict-like of dict-like
            Configuration of the optimization variables. See API description.
        """
        AbstractOptimizer.__init__(self, api_config)
        self.best = [] # {value:eval,vars:{}}
        self.parser = Parser(api_config)
        mean , var = self.parser.initial_mean_and_variance()
        self.mean = np.array(mean)
        self.var_covar = np.array(var)

        

    def suggest(self, n_suggestions=1):
        result = []
        for i in range(0,n_suggestions):
            result.append(self.parser.convert_for_outside(np.random.multivariate_normal(self.mean,self.var_covar)))
        return result
    

    def observe(self, X, y):
        """Send an observation of a suggestion back to the optimizer.

        Parameters
        ----------
        X : list of dict-like
            Places where the objective function has already been evaluated.
            Each suggestion is a dictionary where each key corresponds to a
            parameter being optimized.
        y : array-like, shape (n,)
            Corresponding values where objective has been evaluated
        """
        for xx, yy in zip(X, y):
            self.best.append({"value":yy,"indiv":xx})
        self.best = sorted(self.best,key=lambda x:x["value"])
        self.best = self.best[0:15]
        
        if(len(self.best)<4):
            # dont update with less than 4 elements 
            return 
        
        #new matrixn
        vectors = [self.parser.convert_for_inside(self.best[0]["indiv"])]
        new_mean = self.parser.convert_for_inside(self.best[0]["indiv"])
        for i in range(1,len(self.best)):
            tmp = self.parser.convert_for_inside(self.best[i]["indiv"])
            vectors.append(tmp)
            new_mean = new_mean + tmp
        new_mean = new_mean / len(self.best)
        
        new_var = np.zeros((len(new_mean),len(new_mean)))
        
        for v in vectors:
            new_var = new_var + v[np.newaxis].T.dot(v[np.newaxis])
        new_var = new_var / len(self.best)
        
        self.mean = new_mean
        self.var_covar = new_var
        
        


if __name__ == "__main__":
    experiment_main(CrossEnthropy)
